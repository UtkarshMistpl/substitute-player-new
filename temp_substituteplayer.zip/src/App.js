// import logo from "./logo.svg";
import "./App.css";
import Pages from "./routes/routes";
import "bootstrap/dist/css/bootstrap.min.css";
function App() {
	return (
		<div className="App">
			<Pages />
		</div>
	);
}

export default App;
