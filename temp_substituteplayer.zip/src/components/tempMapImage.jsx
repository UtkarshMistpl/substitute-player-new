import React from "react";
import tempMap from "../assets/background/temMapImage.jpg";

const TempMapImage = () => {
	return (
		<>
			<img className="img-fluid" src={tempMap} />
		</>
	);
};

export default TempMapImage;
