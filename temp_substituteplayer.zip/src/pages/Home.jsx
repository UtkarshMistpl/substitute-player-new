import React from "react";
import FilterForm from "../components/filterForm";
import tempMap from "../assets/background/temMapImage.jpg";
import { Many } from "lodash";
import MyMapComponent from "../components/maps";
const Home = () => {
	return (
		<>
			<div className="mt-5 pt-5">
				<FilterForm />

				{/* <MyMapComponent /> */}
				{/* <MultiSelectComponents /> */}
				{/* <h1>Hello world!</h1> */}
			</div>
			<div className="container-fluid">
				<div className="row justify-content-center">
					<div className="col-11 col-md-8 col-lg-6">
						{/* <img className="img-fluid" src={tempMap} /> */}
						<MyMapComponent />
					</div>
				</div>
			</div>
		</>
	);
};

export default Home;
